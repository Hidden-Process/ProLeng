if ( 1 < 2 )  
     a = 1;
else 
     a = 2;
print (a);