x=6;
y=2;
{
    p = q = 2;
    zeta = p+q;
}
print (zeta+x/y);
