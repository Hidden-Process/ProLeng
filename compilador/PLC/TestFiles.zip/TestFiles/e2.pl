x=1;
if ( a != b ) 
     if ( b == c )
           x = x+2;
     else
           x = x+3;
print (x);                 